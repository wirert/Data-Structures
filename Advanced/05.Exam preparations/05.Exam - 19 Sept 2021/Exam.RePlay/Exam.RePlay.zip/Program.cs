﻿using System;

namespace Exam.RePlay
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
