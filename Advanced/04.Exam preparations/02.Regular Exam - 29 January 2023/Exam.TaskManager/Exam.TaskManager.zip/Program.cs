﻿using System;
using System.Collections.Generic;

namespace Exam.TaskManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
