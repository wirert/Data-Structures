﻿using System;
namespace TripAdministrations
{
    public enum Transportation
    {
        BUS,
        PLANE,
        NONE
    }
}
